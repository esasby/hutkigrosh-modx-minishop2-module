<?php

$_lang['area_msphutkigrosh'] = "Hutkigrosh";

$_lang['setting_ms2_msphutkigrosh_shop_name'] = 'Shop name';
$_lang['setting_ms2_msphutkigrosh_shop_name_desc'] = 'Your shop short name';

$_lang['setting_ms2_msphutkigrosh_api_token'] = 'API Token';
$_lang['setting_ms2_msphutkigrosh_api_token_desc'] = 'API token for Hutkigrosh gateway (obtained from your account)';

$_lang['setting_ms2_msphutkigrosh_service_id'] = 'Service ID';
$_lang['setting_ms2_msphutkigrosh_service_id_desc'] = 'Service code from "Services" list (filled by "Actualize" button)';

$_lang['setting_ms2_msphutkigrosh_retail_outlet_id'] = 'Retail Outlet ID';
$_lang['setting_ms2_msphutkigrosh_retail_outlet_id_desc'] = 'Retail outlet code from "Retail Outlets" list (filled by "Actualize" button)';

$_lang['setting_ms2_msphutkigrosh_cash_box_id'] = 'Cash Box ID';
$_lang['setting_ms2_msphutkigrosh_cash_box_id_desc'] = 'Cash box code from "Cash Boxes" list (filled by "Actualize" button)';

$_lang['setting_ms2_msphutkigrosh_sandbox'] = 'Sandbox';
$_lang['setting_ms2_msphutkigrosh_sandbox_desc'] = 'Sandbox mode. If enabled, all requests will be sent to the test server';

$_lang['setting_ms2_msphutkigrosh_debug_mode'] = 'Debug mode';
$_lang['setting_ms2_msphutkigrosh_debug_mode_desc'] = 'If enabled, additional debug information will be logged';

$_lang['setting_ms2_msphutkigrosh_instructions_section'] = 'Payment instructions';
$_lang['setting_ms2_msphutkigrosh_instructions_section_desc'] = 'If enabled, the customer will see payment instructions on the success page';

$_lang['setting_ms2_msphutkigrosh_qrcode_section'] = 'QR-code';
$_lang['setting_ms2_msphutkigrosh_qrcode_section_desc'] = 'If enabled, the customer will see a QR-code image on the success page';

$_lang['setting_ms2_msphutkigrosh_webpay_section'] = 'Card payment (Webpay)';
$_lang['setting_ms2_msphutkigrosh_webpay_section_desc'] = 'If enabled, the customer will see a "Pay with card" button on the success page';

$_lang['setting_ms2_msphutkigrosh_notification_email'] = 'Email notification';
$_lang['setting_ms2_msphutkigrosh_notification_email_desc'] = 'If enabled, Hutkigrosh gateway will send email notification to customer';

$_lang['setting_ms2_msphutkigrosh_notification_sms'] = 'SMS notification';
$_lang['setting_ms2_msphutkigrosh_notification_sms_desc'] = 'If enabled, Hutkigrosh gateway will send SMS notification to customer';

$_lang['setting_ms2_msphutkigrosh_bill_status_pending'] = 'Bill status pending';
$_lang['setting_ms2_msphutkigrosh_bill_status_pending_desc'] = 'Order status when bill is successfully created';

$_lang['setting_ms2_msphutkigrosh_bill_status_payed'] = 'Bill status payed';
$_lang['setting_ms2_msphutkigrosh_bill_status_payed_desc'] = 'Order status when bill is successfully paid';

$_lang['setting_ms2_msphutkigrosh_bill_status_failed'] = 'Bill status failed';
$_lang['setting_ms2_msphutkigrosh_bill_status_failed_desc'] = 'Order status when bill creation fails';

$_lang['setting_ms2_msphutkigrosh_bill_status_canceled'] = 'Bill status canceled';
$_lang['setting_ms2_msphutkigrosh_bill_status_canceled_desc'] = 'Order status when bill payment is canceled';

$_lang['setting_ms2_msphutkigrosh_success_resource_id'] = 'Success resource ID';
$_lang['setting_ms2_msphutkigrosh_success_resource_id_desc'] = 'Resource ID for redirect on successful bill creation';

$_lang['setting_ms2_msphutkigrosh_failed_resource_id'] = 'Failed resource ID';
$_lang['setting_ms2_msphutkigrosh_failed_resource_id_desc'] = 'Resource ID for redirect on bill creation failure';

$_lang['setting_ms2_msphutkigrosh_due_interval'] = 'Bill due interval (days)';
$_lang['setting_ms2_msphutkigrosh_due_interval_desc'] = 'How many days the bill will be available for payment';

$_lang['setting_ms2_msphutkigrosh_erip_path'] = 'ERIP path';
$_lang['setting_ms2_msphutkigrosh_erip_path_desc'] = 'Path in the ERIP tree where the customer should find the bill';

$_lang['hutkigrosh.webpay.tab.label'] = 'Pay with card';
$_lang['hutkigrosh.webpay.details'] = 'You can pay bill with Visa, Mastercard or Belcard via WebPay';
$_lang['hutkigrosh.webpay.msg.success'] = 'Webpay: payment completed!';
$_lang['hutkigrosh.webpay.msg.failed'] = 'Webpay: payment failed!';
$_lang['hutkigrosh.qrcode.tab.label'] = 'Pay with QR-code';
$_lang['hutkigrosh.qrcode.details'] = 'Pay this bill via mobile banking app using QR-code';
$_lang['hutkigrosh.qrcode.label'] = 'Pay via QR-code';

$_lang['ms2_msphutkigrosh_tab_settings'] = 'Hutkigrosh Settings';
$_lang['ms2_msphutkigrosh_btn_actualize'] = 'Actualize';
$_lang['ms2_msphutkigrosh_err_no_token'] = 'Please fill in the API Token field before actualizing';
$_lang['ms2_msphutkigrosh_err_metadata'] = 'Error retrieving data from Hutkigrosh server';
