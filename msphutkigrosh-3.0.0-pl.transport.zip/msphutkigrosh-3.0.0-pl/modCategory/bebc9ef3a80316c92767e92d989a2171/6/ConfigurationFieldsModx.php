<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 17.08.2018
 * Time: 8:38
 */

namespace esas\cmsgate\hutkigrosh;

use esas\hutkigrosh\ConfigurationFields;
use esas\cmsgate\ConfigFields;

class ConfigurationFieldsModx extends ConfigFieldsHutkigrosh
{
    const SUCCESS_RESOURCE_ID = 'hutkigrosh_success_resource_id';
    const FAILED_RESOURCE_ID = 'hutkigrosh_failed_resource_id';

    const SHOP_NAME = 'hutkigrosh_shop_name';
    const API_TOKEN = 'hutkigrosh_api_token';
    const SERVICE_ID = 'hutkigrosh_service_id';
    const RETAIL_OUTLET_ID = 'hutkigrosh_retail_outlet_id';
    const CASH_BOX_ID = 'hutkigrosh_cash_box_id';
    const SANDBOX = 'hutkigrosh_sandbox';
    const INSTRUCTIONS_SECTION = 'hutkigrosh_instructions_section';
    const QRCODE_SECTION = 'hutkigrosh_qrcode_section';
    const WEBPAY_SECTION = 'hutkigrosh_webpay_section';
    const EMAIL_NOTIFICATION = 'hutkigrosh_notification_email';
    const SMS_NOTIFICATION = 'hutkigrosh_notification_sms';
    const DEBUG_MODE = 'hutkigrosh_debug_mode';
    const COMPLETION_TEXT = 'hutkigrosh_completion_text';
    const ERIP_PATH = 'hutkigrosh_erip_path';
    const PAYMENT_METHOD_NAME = 'hutkigrosh_payment_method_name';
    const PAYMENT_METHOD_DETAILS = 'hutkigrosh_payment_method_details';
    const BILL_STATUS_PENDING = 'hutkigrosh_bill_status_pending';
    const BILL_STATUS_PAYED = 'hutkigrosh_bill_status_payed';
    const BILL_STATUS_FAILED = 'hutkigrosh_bill_status_failed';
    const BILL_STATUS_CANCELED = 'hutkigrosh_bill_status_canceled';
    const DUE_INTERVAL = 'hutkigrosh_due_interval';
    const METADATA_CACHE = 'hutkigrosh_metadata_cache';
}