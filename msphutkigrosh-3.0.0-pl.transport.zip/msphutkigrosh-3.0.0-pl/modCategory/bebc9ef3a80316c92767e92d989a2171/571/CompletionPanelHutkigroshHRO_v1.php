<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 10.10.2018
 * Time: 11:27
 */

namespace esas\cmsgate\hutkigrosh\hro\client;


use esas\cmsgate\hro\accordions\AccordionHRO;
use esas\cmsgate\hro\accordions\AccordionHROFactory;
use esas\cmsgate\hro\accordions\AccordionTabHROFactory;
use esas\cmsgate\hro\panels\MessagesPanelHROFactory;
use esas\cmsgate\hutkigrosh\utils\ResourceUtilsHutkigrosh;
use esas\cmsgate\hutkigrosh\view\client\ClientViewFieldsHutkigrosh;
use esas\cmsgate\lang\Translator;
use esas\cmsgate\utils\htmlbuilder\Attributes as attribute;
use esas\cmsgate\utils\htmlbuilder\Elements as element;

/**
 * Class CompletionPanelHutkigrosh используется для формирования итоговой страницы. Основной класс
 * для темазависимого представления (HGCMS-23).
 * Разбит на множество мелких методов для возможности легкого переопрделения. Что позволяет формировать итоговоую
 * страницу в тегах и CSS-классах принятых в конкретных CMS
 * @package esas\hutkigrosh\view\client
 */
class CompletionPanelHutkigroshHRO_v1 implements CompletionPanelHutkigroshHRO
{
    /**
     * Флаг, когда только один таб
     * и не нужна возможность выбора (например при renderWebpayOnly)
     * @var bool
     */
    private $onlyOneTab = false;

    protected $completionText;
    protected $instructionText;
    protected $webpayForm;
    protected $webpayStatus;
    protected $qrCode;
    /**
     * @var boolean
     */
    protected $instructionSectionEnable;
    /**
     * @var boolean
     */
    protected $qrcodeSectionEnable;
    /**
     * @var boolean
     */
    protected $webpaySectionEnable;
    protected $additionalCSSFile;

    /**
     * @var bool
     */
    protected $orderCanBePayed = false;

    /**
     * @param mixed $completionText
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setCompletionText($completionText) {
        $this->completionText = $completionText;
        return $this;
    }

    /**
     * @param mixed $instructionText
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setInstructionText($instructionText) {
        $this->instructionText = $instructionText;
        return $this;
    }

    /**
     * @param mixed $qrCode
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setQrCode($qrCode) {
        $this->qrCode = $qrCode;
        return $this;
    }

    /**
     * @param mixed $webpayForm
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setWebpayForm($webpayForm) {
        $this->webpayForm = $webpayForm;
        return $this;
    }

    /**
     * @param mixed $webpayStatus
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setWebpayStatus($webpayStatus) {
        $this->webpayStatus = $webpayStatus;
        return $this;
    }

    /**
     * @param bool $instructionSectionEnable
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setInstructionsSectionEnabled($instructionSectionEnable) {
        $this->instructionSectionEnable = $instructionSectionEnable;
        return $this;
    }

    /**
     * @param bool $qrcodeSectionEnable
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setQrcodeSectionEnabled($qrcodeSectionEnable) {
        $this->qrcodeSectionEnable = $qrcodeSectionEnable;
        return $this;
    }

    /**
     * @param bool $webpaySectionEnable
     * @return CompletionPanelHutkigroshHRO_v1
     */
    public function setWebpaySectionEnabled($webpaySectionEnable) {
        $this->webpaySectionEnable = $webpaySectionEnable;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function setOrderCanBePayed($orderCanBePayed) {
        $this->orderCanBePayed = $orderCanBePayed;
        return $this;
    }

    public function build() {
        if (!$this->orderCanBePayed) {
            return MessagesPanelHROFactory::findBuilder()->build();
        }
        $this->onlyOneTab = false;
        return element::content(
            element::div(
                attribute::id("completion-text"),
                attribute::clazz($this->getCssClass4CompletionTextDiv()),
                element::content($this->completionText)
            ),
            $this->elementTabs(),
            $this->addCss()
        );
    }

    const TABS_ID = "hutkigrosh-completion-tabs";

    public function renderWebpayOnly() {
        if (!$this->orderCanBePayed) {
            return MessagesPanelHROFactory::findBuilder()->build();
        }
        $completionPanel =
            $this->elementTab(
                self::TAB_KEY_WEBPAY,
                $this->getWebpayTabLabel(),
                $this->elementWebpayTabContent(),
                false
            );
        echo $completionPanel;
    }

    public function redirectWebpay() {
        if (!$this->orderCanBePayed) {
            echo MessagesPanelHROFactory::findBuilder()->build();
        }
        $this->onlyOneTab = true;
        $completionPanel = element::content(
            $this->elementTab(
                self::TAB_KEY_WEBPAY,
                $this->getWebpayTabLabel(),
                $this->elementWebpayTabContent(),
                false
            ),
            element::includeFile(dirname(__FILE__) . "/webpayAutoSubmitJs.php", ["completionPanel" => $this])

        );
        echo $completionPanel;
    }

    public function elementTabs() {
        $accordion = $this->accordionBuilder()
            ->setId(self::TABS_ID)
            ->addTab($this->elementInstructionsTab())
            ->addTab($this->elementQRCodeTab())
            ->addTab($this->elementWebpayTab());
        return $accordion->build();
    }

    /**
     * @return AccordionHRO
     */
    protected function accordionBuilder() {
        return AccordionHROFactory::findBuilder();
    }

    public function addCss() {
        return array(
            element::styleFile($this->additionalCSSFile)
        );
    }

    /**
     * @return string
     */
    public function getInstructionsTabLabel() {
        return Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::INSTRUCTIONS_TAB_LABEL);
    }

    /**
     * @return string
     */
    public function getQRCodeTabLabel() {
        return Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::QRCODE_TAB_LABEL);
    }

    /**
     * @return string
     */
    public function getQRCodeDetails() {
        return strtr(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::QRCODE_DETAILS), array(
            "@qr_code" => $this->qrCode
        ));
    }

    /**
     * @return string
     */
    public function getWebpayTabLabel() {
        return Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::WEBPAY_TAB_LABEL);
    }

    public function elementTab($key, $header, $body, $selectable = true) {
        return AccordionTabHROFactory::findBuilder()
            ->setChecked($this->isTabChecked($key))
            ->setHeader($header)
            ->setBody($body)
            ->setKey($key);
    }

    public function isTabChecked($tabKey) {
        if ($this->isOnlyOneTabEnabled())
            return true;
        $webpayStatusPresent = '' != $this->webpayStatus;
        switch ($tabKey) {
            case self::TAB_KEY_INSTRUCTIONS:
                return !$webpayStatusPresent;
            case self::TAB_KEY_WEBPAY:
                return $webpayStatusPresent;
            default:
                return false;
        }
    }

    public function isOnlyOneTabEnabled() {
        if ($this->onlyOneTab)
            return true;
        $enabledTabsCount = 0;
        if ($this->instructionSectionEnable)
            $enabledTabsCount++;
        if ($this->qrcodeSectionEnable)
            $enabledTabsCount++;
        if ($this->webpaySectionEnable)
            $enabledTabsCount++;
        return $enabledTabsCount == 1;
    }

    const TAB_KEY_WEBPAY = "webpay";
    const TAB_KEY_INSTRUCTIONS = "instructions";
    const TAB_KEY_QRCODE = "qrcode";

    public function elementWebpayTab() {
        if ($this->webpaySectionEnable) {
            return $this->elementTab(
                self::TAB_KEY_WEBPAY,
                $this->getWebpayTabLabel(),
                $this->elementWebpayTabContent());
        }
        return "";
    }

    public function elementInstructionsTab() {
        if ($this->instructionSectionEnable) {
            return $this->elementTab(
                self::TAB_KEY_INSTRUCTIONS,
                $this->getInstructionsTabLabel(),
                $this->instructionText);
        }
        return "";
    }

    public function elementQRCodeTab() {
        if ($this->qrcodeSectionEnable) {
            return $this->elementTab(
                self::TAB_KEY_QRCODE,
                $this->getQRCodeTabLabel(),
                $this->getQRCodeDetails());
        }
        return "";
    }

    public function setAdditionalCSSFile($fileName) {
        if ("default" == $fileName)
            $this->additionalCSSFile = dirname(__FILE__) . "/completion-default.css";
        else if (!empty($fileName))
            $this->additionalCSSFile = $_SERVER['DOCUMENT_ROOT'] . $fileName;
        return $this;
    }

    const STATUS_PAYED = 'payed';
    const STATUS_FAILED = 'failed';

    public function elementWebpayTabContent() {
        $ret =
            element::div(
                attribute::id("webpay_details"),
                element::content(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::WEBPAY_DETAILS)),
                element::br());

        $ret .= $this->elementWebpayTabContentResultMsg($this->webpayStatus);

        if ("" != $this->webpayForm) {
            $ret .=
                element::div(
                    attribute::id("webpay"),
                    attribute::align("right"),
                    element::img(
                        attribute::id("webpay-ps-image"),
                        attribute::src(ResourceUtilsHutkigrosh::getPsImageUrl()),
                        attribute::alt("")
                    ),
                    element::br(),
                    element::content($this->webpayForm),
                    element::includeFile(dirname(__FILE__) . "/webpayJs.php", ["completionPanel" => $this]));
        } else {
            $ret .=
                element::div(
                    attribute::id("webpay_message_unavailable"),
                    attribute::clazz($this->getCssClass4MsgUnsuccess()),
                    element::content(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::WEBPAY_MSG_UNAVAILABLE)));
        }
        return $ret;
    }

    public function elementWebpayTabContentResultMsg($status) {
        if (self::STATUS_PAYED == $status) {
            return
                element::div(
                    attribute::clazz($this->getCssClass4MsgSuccess()),
                    attribute::id("webpay_message"),
                    element::content(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::WEBPAY_MSG_SUCCESS)));
        } elseif (self::STATUS_FAILED == $status) {
            return
                element::div(
                    attribute::clazz($this->getCssClass4MsgUnsuccess()),
                    attribute::id("webpay_message"),
                    element::content(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::WEBPAY_MSG_UNSUCCESS)));
        } else
            return "";
    }

    /**
     * @return string
     */
    public function getCssClass4MsgSuccess()
    {
        return "";
    }

    /**
     * @return string
     */
    public function getCssClass4MsgUnsuccess() {
        return "";
    }

    /**
     * @return string
     */
    public function getCssClass4CompletionTextDiv() {
        return "";
    }

    /**
     * used in webpayJs.php
     * @return string
     */
    public function getCssClass4WebpayButton() {
        return $this->getCssClass4Button();
    }

    /**
     * @return string
     */
    public function getCssClass4Button() {
        return "";
    }

    public function getCssClass4FormInput() {
        return "";
    }

    public static function builder() {
        return new CompletionPanelHutkigroshHRO_v1();
    }
}