<?php
use esas\cmsgate\hutkigrosh\controllers\ControllerWebpayFormModxMinishop2;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshWebPayRq;
use esas\cmsgate\hutkigrosh\view\client\ClientViewFieldsHutkigrosh;
use esas\cmsgate\hutkigrosh\wrappers\ConfigurationWrapperModxMinishop2;
use esas\cmsgate\hutkigrosh\wrappers\OrderWrapperModxMinishop2;
use esas\cmsgate\CmsPlugin;
use esas\cmsgate\hutkigrosh\RegistryHutkigroshMs;
use esas\cmsgate\lang\Translator;

global $modx;

$modx->lexicon->load('msp.hutkigrosh:default');

(new CmsPlugin(dirname(__FILE__, 5) . '/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshMs($modx))
    ->init();

$tpl = $modx->getOption('tpl', $scriptProperties, 'tpl.mspHutkigrosh.success');

$configuration = new ConfigurationWrapperModxMinishop2($modx);
$order = $modx->getObject('msOrder', $_GET['msorder']);
if (!$order) return 'Order not found';

$orderWrapper = new OrderWrapperModxMinishop2($order);
$chunkProperties = array(
    'order_number' => $orderWrapper->getOrderId(),
    'order_instruction' => $configuration->cookText(Translator::fromRegistry()->translate(ClientViewFieldsHutkigrosh::INSTRUCTIONS), $orderWrapper)
);

if ($configuration->isWebpaySectionEnabled()) {
    try {
        $controller = new ControllerWebpayFormModxMinishop2($configuration);
        $webpayResp = $controller->process($orderWrapper);
        if ($webpayResp && !$webpayResp->hasError()) {
            $chunkProperties['webpay_button_enabled'] = true;
            $chunkProperties['webpay_status'] = isset($_GET['webpay_status']) ? $_GET['webpay_status'] : '';
            $chunkProperties['webpay_form'] = $webpayResp->getHtmlForm();
        }
    } catch (\Exception $e) {
        $chunkProperties['webpay_error'] = $e->getMessage();
    }
}

$extId = $orderWrapper->getExtId();
if ($configuration->isQRCodeSectionEnabled() && !empty($extId)) {
    try {
        $hg = new HutkigroshProtocol($configuration);
        $webPayRq = new HutkigroshWebPayRq();
        $webPayRq->setBillId($extId);
        $qrData = $hg->apiQRCode($webPayRq);
        if (isset($qrData['image']) && !empty($qrData['image'])) {
            $chunkProperties['qr_code'] = true;
            $chunkProperties['qr_image'] = $qrData['image'];
            $chunkProperties['qr_tinylink'] = isset($qrData['tinyLink']) ? $qrData['tinyLink'] : '';
        }
    } catch (\Exception $e) {
        $chunkProperties['qr_error'] = $e->getMessage();
    }
}

$pdoTools = $modx->getService('pdoTools');
return $pdoTools->getChunk($tpl, $chunkProperties);
