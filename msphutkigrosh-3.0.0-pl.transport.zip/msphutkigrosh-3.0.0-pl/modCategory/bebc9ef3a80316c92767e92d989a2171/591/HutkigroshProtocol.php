<?php

namespace esas\cmsgate\hutkigrosh\protocol;

use esas\cmsgate\protocol\Amount;
use esas\cmsgate\protocol\ProtocolCurl;
use esas\cmsgate\protocol\RqMethod;
use esas\cmsgate\protocol\RsType;
use esas\cmsgate\utils\EncodingUtils;
use esas\cmsgate\utils\NumberUtils;
use Exception;
use Throwable;

class HutkigroshProtocol extends ProtocolCurl
{
    private static $cookies_file;
    public $cookies_dir;
    public $rqCode;
    public $rqProviderMetadata;

    const API_URL = 'https://api.hgrosh.by/eripservice/';
    const API_URL_TEST = 'https://api-sandbox.hgrosh.by/eripservice/';

    public function __construct($configWrapper)
    {
        parent::__construct(self::API_URL, self::API_URL_TEST, $configWrapper);
        if (!isset(self::$cookies_file)) {
            self::$cookies_file = 'cookies-' . time() . '.txt';
        }
        $dir = $this->configurationWrapper->getCookiePath();
        if (empty($dir)) {
            $dir = dirname(__FILE__) . DIRECTORY_SEPARATOR . "cookies";
        }
        $this->setCookiesDir($dir);
    }

    public function setCookiesDir($dir)
    {
        $dir = rtrim($dir, '\\/');
        if (!is_dir($dir) && !mkdir($dir)) {
            throw new Exception("Can not create dir[" . $dir . "]");
        }
        $this->cookies_dir = $dir;
        $this->logger->debug("Cookies dir is set to: " . $this->cookies_dir);
    }

    public function checkProviderMetadata(HutkigroshRq $billNewRq)
    {
        $resArray = $this->requestGet('service-provider/metadata?api-version=3.0', '');

        if (isset($resArray['services']) && !empty($resArray['services'])) {
            $_flgServiceActive = false;
            $billNewRq->setServices($resArray['services']);
            foreach ($resArray['services'] as $_service) {
                if ((int)$_service['code'] == (int)$billNewRq->getServiceId()) {
                    $billNewRq->setPaymentChannels($_service['paymentChannels']);
                    $_flgServiceActive = true;
                    break;
                }
            }
            if (count($resArray['services']) == 1 && !$_flgServiceActive) {
                $billNewRq->setServiceId($resArray['services'][0]['code']);
                $billNewRq->setPaymentChannels($resArray['services'][0]['paymentChannels']);
                $_flgServiceActive = true;
            }
            if (!$_flgServiceActive) {
                $this->logger->error("Service not found in metadata");
            }
        } else {
            $this->logger->error("Empty services in metadata");
        }

        $_retailOutletsId = false;
        if (isset($resArray['retailOutlets']) && !empty($resArray['retailOutlets'])) {
            $_flgRetailOutlets = false;
            $billNewRq->setRetailOutlets($resArray['retailOutlets']);
            foreach ($resArray['retailOutlets'] as $_key => $_retailOutlets) {
                if ((int)$_retailOutlets['code'] == (int)$billNewRq->getRetailOutletId()) {
                    $_flgRetailOutlets = true;
                    $_retailOutletsId = $_key;
                    break;
                }
            }
            if (count($resArray['retailOutlets']) == 1 && !$_flgRetailOutlets) {
                $billNewRq->setRetailOutletId($resArray['retailOutlets'][0]['code']);
                $_flgRetailOutlets = true;
                $_retailOutletsId = 0;
            }
            if (!$_flgRetailOutlets) {
                $this->logger->error("RetailOutlet not found in metadata");
            }
        } else {
            $this->logger->error("Empty retailOutlets in metadata");
        }

        if (isset($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"]) && !empty($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"]) && $_retailOutletsId !== false) {
            $_flgCashBoxes = false;
            $billNewRq->setCashboxes($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"]);
            foreach ($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"] as $_cashBoxes) {
                if ((int)$_cashBoxes['code'] == (int)$billNewRq->getCashboxId()) {
                    $_flgCashBoxes = true;
                    break;
                }
            }
            if (count($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"]) == 1 && !$_flgCashBoxes) {
                $billNewRq->setCashboxId($resArray['retailOutlets'][$_retailOutletsId]["cashBoxes"][0]['code']);
                $_flgCashBoxes = true;
            }
            if (!$_flgCashBoxes) {
                $this->logger->error("CashBox not found in metadata");
            }
        }
        $this->rqProviderMetadata = $resArray;
    }

    public function apiBillNew(HutkigroshBillNewRq $billNewRq)
    {
        $resp = new HutkigroshBillNewRs();
        $loggerMainString = 'Order[' . $billNewRq->getInvId() . ']: ';
        try {
            $this->logger->debug($loggerMainString . 'apiBillNew started');
            $this->checkProviderMetadata($billNewRq);

            $json = [];
            $json['invoiceNumber'] = $billNewRq->getInvId();
            $json['invoiceDefinition'] = [];
            $json['invoiceDefinition']['invoiceContext'] = [];
            $json['invoiceDefinition']['invoiceContext']['currency'] = $billNewRq->getAmount()->getCurrency();
            $json['invoiceDefinition']['invoiceContext']['purpose'] = 'purpose';

            if (!empty($billNewRq->getProducts())) {
                $products = array();
                foreach ($billNewRq->getProducts() as $pr) {
                    $product = array();
                    if (!empty($pr->getInvId())) {
                        $product['code'] = $pr->getInvId();
                    }
                    $product['name'] = htmlentities(EncodingUtils::convertToUtf8($pr->getName()), ENT_XML1);
                    $product['unitPrice'] = NumberUtils::formatDecimalWithPoint($pr->getUnitPrice());
                    $product['quantity'] = NumberUtils::formatDecimalWithPoint($pr->getCount());
                    $product['description'] = htmlentities(EncodingUtils::convertToUtf8($pr->getName()), ENT_XML1);
                    $products[] = $product;
                }
                $json['invoiceDefinition']['invoiceContext']['context']['products'] = $products;
            }

            $json['invoiceDefinition']['payerInfo'] = [];
            $json['invoiceDefinition']['payerInfo']['payer'] = ['firstName' => preg_replace('/\s*-\s*/', '-', trim(EncodingUtils::convertToUtf8($billNewRq->getFullName())))];
            if (!empty($billNewRq->getFullAddress())) {
                $json['invoiceDefinition']['payerInfo']['address'] = ['line1' => EncodingUtils::convertToUtf8($billNewRq->getFullAddress())];
            }
            $json['invoiceDefinition']['payerInfo']['customerNotification'] = ['events' => ['CREATED']];

            if (!empty($billNewRq->getEmail()) && preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/', $billNewRq->getEmail())) {
                $json['invoiceDefinition']['payerInfo']['email'] = $billNewRq->getEmail();
                $json['invoiceDefinition']['payerInfo']['customerNotification']['notifyByEmail'] = $billNewRq->isNotifyByEMail() ? true : false;
            }
            if (!empty($billNewRq->getMobilePhone())) {
                $json['invoiceDefinition']['payerInfo']['phone'] = $billNewRq->getMobilePhone();
                $json['invoiceDefinition']['payerInfo']['customerNotification']['notifyBySms'] = $billNewRq->isNotifyByMobilePhone() ? true : false;
            }
            $json['invoiceDefinition']['paymentRules'] = ['baseRules' => ['invoiceType' => 'ONETIME']];
            $json['invoiceDefinition']['paymentChannels'] = $billNewRq->getPaymentChannels();
            $json['serviceContext'] = [];
            $json['serviceContext']['serviceId'] = (int)$billNewRq->getServiceId();
            $json['serviceContext']['retailOutletId'] = (int)$billNewRq->getRetailOutletId();
            $json['serviceContext']['cashboxId'] = (int)$billNewRq->getCashboxId();

            $json = json_encode($json);
            $this->logger->debug($loggerMainString . ' Send json: ' . $json);

            $resArray = $this->requestPost('invoices?api-version=3.0', $json, RsType::_ARRAY);

            if (!is_array($resArray) || !isset($resArray['invoiceId'])) {
                $errMsg = isset($resArray['message']) ? $resArray['message'] : 'Unknown error';
                throw new Exception("Wrong response: " . $errMsg . " (code " . $this->rqCode . ")", HutkigroshRs::ERROR_RESP_FORMAT);
            }
            $resp->setResponseCode($this->rqCode);
            $resp->setBillId($resArray['invoiceId']);
            $this->logger->debug($loggerMainString . "apiBillNew ended");
        } catch (Throwable $e) {
            $this->logger->error($loggerMainString . "apiBillNew exception", $e);
            $resp->setResponseCode($e->getCode());
            $resp->setResponseMessage($e->getMessage());
        } catch (Exception $e) {
            $this->logger->error($loggerMainString . "apiBillNew exception", $e);
            $resp->setResponseCode($e->getCode());
            $resp->setResponseMessage($e->getMessage());
        }
        return $resp;
    }

    public function apiWebPay(HutkigroshWebPayRq $webPayRq)
    {
        $resp = new HutkigroshWebPayRs();
        $loggerMainString = "Bill[" . $webPayRq->getBillId() . "]: ";
        try {
            $this->logger->debug($loggerMainString . "apiWebPay started");
            $resStr = $this->requestGet('invoices/' . $webPayRq->getBillId() . '/payment-form?' . http_build_query([
                    'paymentChannel' => 'ERIP',
                    'returnUrl' => htmlspecialchars($webPayRq->getReturnUrl()),
                    'cancelReturnUrl' => htmlspecialchars($webPayRq->getCancelReturnUrl()),
                    'submitValue' => EncodingUtils::convertToUtf8($webPayRq->getButtonLabel())
                ]), '');
            if (isset($resStr['code']) || !isset($resStr['form']) || empty($resStr['form'])) {
                throw new Exception("Неверный формат ответа", HutkigroshRs::ERROR_RESP_FORMAT);
            }
            $resp->setResponseCode($this->rqCode);
            $resp->setHtmlForm(EncodingUtils::convertFromUtf8($resStr['form']));
            $this->logger->debug($loggerMainString . "apiWebPay ended");
        } catch (Throwable $e) {
            $this->logger->error($loggerMainString . "apiWebPay exception: ", $e);
            $resp->setResponseCode(HutkigroshRs::ERROR_DEFAULT);
            $resp->setResponseMessage($e->getMessage());
        } catch (Exception $e) {
            $this->logger->error($loggerMainString . "apiWebPay exception: ", $e);
            $resp->setResponseCode(HutkigroshRs::ERROR_DEFAULT);
            $resp->setResponseMessage($e->getMessage());
        }
        return $resp;
    }

    public function apiQRCode(HutkigroshWebPayRq $webPayRq)
    {
        $returnArray = [];
        $loggerMainString = "QR Code [" . $webPayRq->getBillId() . "]: ";
        try {
            $this->logger->debug($loggerMainString . "apiQRCode started");
            $returnArray = $this->requestGet('invoices/' . $webPayRq->getBillId() . '/qr-code?' . http_build_query([
                    'paymentChannel' => 'ERIP'
                ]), '');
            if (isset($returnArray['code']) || !isset($returnArray['image']) || empty($returnArray['image'])) {
                throw new Exception("Неверный формат ответа. " . (isset($returnArray['message']) ? $returnArray['message'] : ''), HutkigroshRs::ERROR_RESP_FORMAT);
            }
            $this->logger->debug($loggerMainString . "apiQRCode ended");
        } catch (Throwable $e) {
            $this->logger->error($loggerMainString . "apiQRCode exception: ", $e);
        } catch (Exception $e) {
            $this->logger->error($loggerMainString . "apiQRCode exception: ", $e);
        }
        return $returnArray;
    }

    public function apiBillInfo(HutkigroshBillInfoRq $billInfoRq)
    {
        $resp = new HutkigroshBillInfoRs();
        $loggerMainString = "Bill[" . $billInfoRq->getBillId() . "]: ";
        try {
            $this->logger->debug($loggerMainString . "apiBillInfo started");
            $resArray = $this->requestGet('invoices/' . $billInfoRq->getBillId() . '?api-version=3.0', '', RsType::_ARRAY);
            if (empty($resArray) || isset($resArray['code'])) {
                throw new Exception("Wrong message format " . (isset($resArray['message']) ? $resArray['message'] : ''), HutkigroshRs::ERROR_RESP_FORMAT);
            }
            $resp->setResponseCode($this->rqCode);
            $resp->setBillId($resArray["id"]);
            $resp->setOrderId($resArray["invoiceBody"]["invoiceNumber"]);
            $resp->setRetailOutletId($resArray["invoiceBody"]["serviceContext"]["retailOutletId"]);
            $resp->setAmount(new Amount($resArray["paidAmount"], $resArray["invoiceBody"]["invoiceDefinition"]["invoiceContext"]["currency"]));
            $resp->setEmail($resArray["invoiceBody"]["invoiceDefinition"]["payerInfo"]["email"]);
            $resp->setMobilePhone($resArray["invoiceBody"]["invoiceDefinition"]["payerInfo"]["phone"]);
            $paidAmount = floatval($resArray["paidAmount"]);
            $totalAmount = floatval($resArray["totalAmount"]);
            $apiState = isset($resArray['state']) ? $resArray['state'] : (isset($resArray['status']) ? $resArray['status'] : '');
            if ($paidAmount > 0 && $paidAmount === $totalAmount) {
                $resp->setStatus('PAYED');
            } elseif ($paidAmount > 0 && $paidAmount < $totalAmount) {
                $resp->setStatus('PENDING');
            } else {
                $resp->setStatus($apiState);
            }
            $this->logger->debug($loggerMainString . "apiBillInfo ended");
        } catch (Throwable $e) {
            $this->logger->error($loggerMainString . "apiBillInfo exception.", $e);
            $resp->setResponseCode($e->getCode());
            $resp->setResponseMessage($e->getMessage());
        } catch (Exception $e) {
            $this->logger->error($loggerMainString . "apiBillInfo exception.", $e);
            $resp->setResponseCode($e->getCode());
            $resp->setResponseMessage($e->getMessage());
        }
        return $resp;
    }

    protected function send($method, $data, $rqMethod, $rsType)
    {
        $cookies_path = $this->cookies_dir . DIRECTORY_SEPARATOR . self::$cookies_file;
        if (!is_file($cookies_path) && !is_writable($this->cookies_dir)) {
            throw new Exception('Cookie file[' . $cookies_path . '] is not writable!');
        }
        try {
            $url = $this->connectionUrl . $method;
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: Bearer ' . $this->configurationWrapper->getHutkigroshApiToken();
            $this->defaultCurlInit($url);
            curl_setopt($this->ch, CURLOPT_HEADER, false);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
            switch ($rqMethod) {
                case RqMethod::_GET:
                    $headers[] = 'Content-Length: ' . strlen($data);
                    break;
                case RqMethod::_POST:
                    curl_setopt($this->ch, CURLOPT_POST, true);
                    curl_setopt($this->ch, CURLOPT_POSTFIELDS, $data);
                    break;
                case RqMethod::_PUT:
                    curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, "PUT");
                    curl_setopt($this->ch, CURLOPT_POSTFIELDS, $data);
                    break;
                case RqMethod::_DELETE:
                    curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                    break;
            }
            if (isset($headers) && is_array($headers))
                curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
            $logStr = $data;
            if (is_array($logStr))
                $logStr = json_encode($logStr);
            $this->logger->info('Sending ' . RqMethod::toString($rqMethod) . ' request[' . $logStr . "] to url[" . $url . "]");
            $response = $this->execCurlAndLog();
            $this->rqCode = curl_getinfo($this->ch, CURLINFO_RESPONSE_CODE);
        } finally {
            curl_close($this->ch);
        }
        return $this->convertRs($response, $rsType);
    }
}
