<?php

use esas\cmsgate\hutkigrosh\wrappers\ConfigurationWrapperModxMinishop2;
use esas\cmsgate\hutkigrosh\controllers\ControllerNotifyModxMinishop2;
use esas\cmsgate\CmsPlugin;
use esas\cmsgate\hutkigrosh\RegistryHutkigroshMs;

if (!isset($modx)) {
    define('MODX_API_MODE', true);
    require dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/index.php';

    $modx->getService('error', 'error.modError');
    $modx->setLogLevel(modX::LOG_LEVEL_ERROR);
}
$modx->error->message = null;

(new CmsPlugin(dirname(__FILE__, 5) . '/core/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshMs($modx))
    ->init();

switch ($_GET['action']) {
    case 'notify':
        $controller = new ControllerNotifyModxMinishop2(new ConfigurationWrapperModxMinishop2($modx));
        $controller->process($_REQUEST['purchaseid']);
        break;
}
