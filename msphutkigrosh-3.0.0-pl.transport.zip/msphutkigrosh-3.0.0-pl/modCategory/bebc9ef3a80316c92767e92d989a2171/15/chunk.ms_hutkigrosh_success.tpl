{$order_instruction|nofilter}
<div id="hutkigrosh_buttons">
    {if $webpay_button_enabled}
    {if $webpay_status == 'payed'}
        <div class="alert alert-success" id="hutkigrosh_message">{'hutkigrosh.webpay.msg.success' | lexicon}</div>
    {elseif $webpay_status == 'failed'}
        <div class="alert alert-danger" id="hutkigrosh_message">{'hutkigrosh.webpay.msg.failed' | lexicon}</div>
    {/if}
        <div id="webpay" class="mb-3">
            <h5>{'hutkigrosh.webpay.tab.label' | lexicon}</h5>
            <p>{'hutkigrosh.webpay.details' | lexicon}</p>
            {$webpay_form|nofilter}
        </div>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script>
            var webpay_form_button = $('#webpay input[type="submit"]');
            webpay_form_button.addClass('btn btn-primary ms2_link');
        </script>
    {/if}
    {if $qr_code}
        <div id="qr_code" class="mb-3">
            <h5>{'hutkigrosh.qrcode.tab.label' | lexicon}</h5>
            <p>{'hutkigrosh.qrcode.details' | lexicon}</p>
            <div class="text-center">
                <img src="data:image/png;base64,{$qr_image}" alt="QR-code" style="max-width:250px;"/>
                {if $qr_tinylink}
                <p class="mt-2"><a href="{$qr_tinylink}" target="_blank" class="btn btn-outline-primary">Оплатить по ссылке</a></p>
                {/if}
            </div>
        </div>
    {/if}
</div>
