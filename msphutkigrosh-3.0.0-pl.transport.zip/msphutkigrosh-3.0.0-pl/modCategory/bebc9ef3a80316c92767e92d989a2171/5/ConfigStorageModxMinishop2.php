<?php
namespace esas\cmsgate\hutkigrosh;

use esas\cmsgate\ConfigStorageCms;

class ConfigStorageModxMinishop2 extends ConfigStorageCms
{
    private $modx;

    public function __construct($modx)
    {
        parent::__construct();
        $this->modx = $modx;
    }

    public function getConfig($key)
    {
        $cmsKey = $this->createCmsRelatedKey($key);
        return $this->modx->getOption($cmsKey, null, '');
    }

    public function saveConfig($key, $value)
    {
        $setting = $this->modx->getObject('modSystemSetting', ['key' => $key]);
        if (!$setting) {
            $setting = $this->modx->newObject('modSystemSetting');
            $setting->set('key', $key);
            $setting->set('namespace', 'minishop2');
            $setting->set('area', 'msphutkigrosh');
        }
        $setting->set('value', $value);
        $setting->save();
    }

    public function convertToBoolean($cmsConfigValue)
    {
        return $cmsConfigValue === '1' || $cmsConfigValue === 'true';
    }

    public function createCmsRelatedKey($key)
    {
        return 'ms2_msphutkigrosh_' . $key;
    }
}
