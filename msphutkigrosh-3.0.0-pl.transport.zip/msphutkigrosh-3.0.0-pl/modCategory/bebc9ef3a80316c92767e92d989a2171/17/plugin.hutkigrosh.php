<?php
/** @var modX $modx */

//use esas\cmsgate\hutkigrosh\utils\LoggerDefault;
use esas\cmsgate\utils\Logger;

switch ($modx->event->name) {
    // добавим автозагрузчик composer-а
    case 'OnMODXInit':
        $file = MODX_CORE_PATH . 'components/minishop2/custom/payment/lib/EsasAutoloader.php';
        if (file_exists($file)) {
            require_once $file;
        }
        Logger::init(); // используем настройки по умолчанию для сохранения логов в безопасном каталоге
        break;

    case 'msOnManagerCustomCssJs':
        $logFile = MODX_CORE_PATH . 'cache/logs/hutkigrosh_debug.log';
        file_put_contents($logFile, date('Y-m-d H:i:s') . " msOnManagerCustomCssJs fired\n", FILE_APPEND);
        file_put_contents($logFile, date('Y-m-d H:i:s') . " controller class: " . get_class($modx->controller) . "\n", FILE_APPEND);
        $modx->controller->addLexiconTopic('minishop2:msp.hutkigrosh');
        $modx->controller->addJavascript(
            MODX_ASSETS_URL . 'components/minishop2/js/mgr/settings/payment/hutkigrosh/tab.js'
        );
        file_put_contents($logFile, date('Y-m-d H:i:s') . " JS added\n", FILE_APPEND);
        break;
}
