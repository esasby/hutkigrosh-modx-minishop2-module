<?php

namespace esas\cmsgate\hutkigrosh\wrappers;

use esas\cmsgate\ConfigFields;
use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use esas\cmsgate\Registry;
use esas\cmsgate\wrappers\ConfigWrapper;
use esas\cmsgate\wrappers\OrderWrapper;

class ConfigWrapperHutkigrosh extends ConfigWrapper
{
    /**
     * @return ConfigWrapperHutkigrosh
     */
    public static function fromRegistry() {
        return Registry::getRegistry()->getConfigWrapper();
    }

    /**
     * Произвольное название интернет-магазина
     * @return string
     */
    public function getShopName()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::shopName());
    }

    /**
     * Токен API для доступа к системе ХуткиГрош
     * @return string
     */
    public function getHutkigroshApiToken()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::apiToken());
    }

    /**
     * @param string $apiToken
     */
    public function setHutkigroshApiToken($apiToken)
    {
        return $this->saveConfig(ConfigFieldsHutkigrosh::apiToken(), $apiToken);
    }

    /**
     * Необходимо ли добавлять кнопку "Инструкция по оплате в ЕРИП"
     * @return boolean
     */
    public function isInstructionsSectionEnabled()
    {
        return $this->checkOn(ConfigFieldsHutkigrosh::instructionsSection());
    }

    /**
     * Необходимо ли добавлять кнопку "оплатить картой"
     * @return boolean
     */
    public function isWebpaySectionEnabled()
    {
        return $this->checkOn(ConfigFieldsHutkigrosh::webpaySection());
    }

    /**
     * Уникальный код торговой точки из списка "Розничные торговые точки"
     * @return string
     */
    public function getRetailOutletId()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::retailOutletId());
    }

    /**
     * Номер услуги из списка "Услуги"
     * @return string
     */
    public function getServiceId()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::serviceId());
    }

    /**
     * Номер кассы из списка "Кассы"
     * @return string
     */
    public function getCashboxId()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::cashboxId());
    }

    /**
     * Необходимо ли добавлять секцию с QR-code
     * @return boolean
     */
    public function isQRCodeSectionEnabled()
    {
        return $this->checkOn(ConfigFieldsHutkigrosh::qrcodeSection());
    }

    /**
     * Включено ли оповещение клиента по Email
     * @return boolean
     */
    public function isEmailNotification()
    {
        return $this->checkOn(ConfigFieldsHutkigrosh::notificationEmail());
    }

    /**
     * Включено ли оповещение клиента по Sms
     * @return boolean
     */
    public function isSmsNotification()
    {
        return $this->checkOn(ConfigFieldsHutkigrosh::notificationSms());
    }

    /**
     * Итоговый текст, отображаемый клиенту после успешного выставления счета
     * @return string
     */
    public function getCompletionText()
    {
        return $this->getConfigOrDefaults(ConfigFieldsHutkigrosh::completionText());
    }

    /**
     * CSS для итогового экрана
     * @return string
     */
    public function getCompletionCssFile()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::completionCssFile());
    }

    /**
     * Путь ЕРИП для отображения в инструкции
     * @return string
     */
    public function getEripPath()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::eripPath());
    }

    /**
     * Кастомный путь к директории cookie файлов
     * @return string
     */
    public function getCookiePath()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::cookiePath());
    }

    /**
     * Какой срок действия счета после его выставления (в днях)
     * @return string
     */
    public function getDueInterval()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::dueInterval());
    }

    /**
     * Название системы для прямой оплаты через Webpay
     * @return string
     */
    public function getPaymentMethodNameWebpay()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::paymentMethodNameWebpay());
    }

    /**
     * Описание системы для прямой оплаты через Webpay
     * @return string
     */
    public function getPaymentMethodDetailsWebpay()
    {
        return $this->getConfig(ConfigFieldsHutkigrosh::paymentMethodDetailsWebpay());
    }

    /**
     * Метод для получения значения параметра по ключу
     * @param $config_key
     * @return bool|string
     */
    public function get($config_key)
    {
        switch ($config_key) {
            case ConfigFieldsHutkigrosh::shopName():
                return $this->getShopName();
            case ConfigFieldsHutkigrosh::apiToken():
                return $this->getHutkigroshApiToken();
            case ConfigFieldsHutkigrosh::retailOutletId():
                return $this->getRetailOutletId();
            case ConfigFieldsHutkigrosh::serviceId():
                return $this->getServiceId();
            case ConfigFieldsHutkigrosh::cashboxId():
                return $this->getCashboxId();
            case ConfigFieldsHutkigrosh::instructionsSection():
                return $this->isInstructionsSectionEnabled();
            case ConfigFieldsHutkigrosh::qrcodeSection():
                return $this->isQRCodeSectionEnabled();
            case ConfigFieldsHutkigrosh::webpaySection():
                return $this->isWebpaySectionEnabled();
            case ConfigFieldsHutkigrosh::notificationEmail():
                return $this->isEmailNotification();
            case ConfigFieldsHutkigrosh::notificationSms():
                return $this->isSmsNotification();
            case ConfigFieldsHutkigrosh::completionText():
                return $this->getCompletionText();
            case ConfigFieldsHutkigrosh::completionCssFile():
                return $this->getCompletionCssFile();
            case ConfigFieldsHutkigrosh::dueInterval():
                return $this->getDueInterval();
            case ConfigFieldsHutkigrosh::eripPath():
                return $this->getEripPath();
            case ConfigFieldsHutkigrosh::cookiePath():
                return $this->getCookiePath();
            case ConfigFieldsHutkigrosh::paymentMethodNameWebpay():
                return $this->getPaymentMethodNameWebpay();
            case ConfigFieldsHutkigrosh::paymentMethodDetailsWebpay():
                return $this->getPaymentMethodDetailsWebpay();
            default:
                return parent::get($config_key);
        }
    }

    /**
     * Подстановка переменных из заказа в итоговый текст
     * @param $text
     * @param OrderWrapper $orderWrapper
     * @return string
     */
    public function cookText($text, $orderWrapper)
    {
        $text = parent::cookText($text, $orderWrapper);
        return strtr($text, array(
            "@erip_path" => $this->getEripPath()
        ));
    }

    /**
     * Значения по умолчанию
     * @param $key
     * @return bool|int|string
     */
    public function getDefaultConfig($key)
    {
        switch ($key) {
            case ConfigFieldsHutkigrosh::notificationEmail():
            case ConfigFieldsHutkigrosh::notificationSms():
            case ConfigFieldsHutkigrosh::instructionsSection():
            case ConfigFieldsHutkigrosh::qrcodeSection():
            case ConfigFieldsHutkigrosh::webpaySection():
            case ConfigFieldsHutkigrosh::sandbox():
                return true;
            case ConfigFieldsHutkigrosh::dueInterval():
                return 2;
            default:
                return Registry::getRegistry()->getTranslator()->getConfigFieldDefault($key);
        }
    }

    protected function needDefaults()
    {
        return !$this->configStorageCms->isStorageInitialised(ConfigFieldsHutkigrosh::apiToken());
    }
}
