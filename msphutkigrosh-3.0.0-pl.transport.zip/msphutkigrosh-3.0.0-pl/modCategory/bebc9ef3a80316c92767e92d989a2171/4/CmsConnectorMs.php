<?php
namespace esas\cmsgate\hutkigrosh;

use esas\cmsgate\CmsConnector;
use esas\cmsgate\hutkigrosh\lang\LocaleLoaderMs;
use esas\cmsgate\Registry;

class CmsConnectorMs extends CmsConnector
{
    /**
     * Для удобства работы в IDE и подсветки синтаксиса.
     * @return $this
     */
    public static function fromRegistry()
    {
        return Registry::getRegistry()->getCmsConnector();
    }

    public function init() {
        parent::init();
    }

    public function createLocaleLoader()
    {
        return new LocaleLoaderMs();
    }

    public function createCommonConfigForm($managedFields)
    {
        // TODO: Implement createCommonConfigForm() method.
    }

    public function createOrderWrapperByOrderId($orderId)
    {
        $modx = RegistryHutkigroshMs::getRegistry()->modx;
        $order = $modx->getObject('msOrder', $orderId);
        return empty($order) ? null : new \esas\cmsgate\hutkigrosh\wrappers\OrderWrapperModxMinishop2($order);
    }

    public function createOrderWrapperForCurrentUser()
    {
        // TODO: Implement createOrderWrapperForCurrentUser() method.
    }

    public function createOrderWrapperByExtId($extId)
    {
        $modx = RegistryHutkigroshMs::getRegistry()->modx;
        $c = $modx->newQuery('msOrder');
        $c->where(array('properties:LIKE' => '%"' . $extId . '"%'));
        $order = $modx->getObject('msOrder', $c);
        return empty($order) ? null : new \esas\cmsgate\hutkigrosh\wrappers\OrderWrapperModxMinishop2($order);
    }

    public function createConfigStorage()
    {
        return new ConfigStorageModxMinishop2(RegistryHutkigroshMs::getRegistry()->modx);
    }

    public function createCmsConnectorDescriptor()
    {
        // TODO: Implement createCmsConnectorDescriptor() method.
    }
}