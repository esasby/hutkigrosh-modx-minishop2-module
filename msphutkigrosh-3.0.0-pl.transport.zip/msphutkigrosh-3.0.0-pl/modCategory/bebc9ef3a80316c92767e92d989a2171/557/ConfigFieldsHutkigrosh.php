<?php

namespace esas\cmsgate\hutkigrosh;

use esas\cmsgate\ConfigFields;

class ConfigFieldsHutkigrosh extends ConfigFields
{
    public static function shopName() { return self::getCmsRelatedKey("shop_name"); }

    public static function apiToken() { return self::getCmsRelatedKey("api_token"); }

    public static function retailOutletId() { return self::getCmsRelatedKey("retail_outlet_id"); }

    public static function serviceId() { return self::getCmsRelatedKey("service_id"); }

    public static function cashboxId() { return self::getCmsRelatedKey("cash_box_id"); }

    public static function instructionsSection() { return self::getCmsRelatedKey("instructions_section"); }

    public static function qrcodeSection() { return self::getCmsRelatedKey("qrcode_section"); }

    public static function webpaySection() { return self::getCmsRelatedKey("webpay_section"); }

    public static function notificationEmail() { return self::getCmsRelatedKey("notification_email"); }

    public static function notificationSms() { return self::getCmsRelatedKey("notification_sms"); }

    public static function completionText() { return self::getCmsRelatedKey("completion_text"); }

    public static function completionCssFile() { return self::getCmsRelatedKey("completion_css_file"); }

    public static function eripPath() { return self::getCmsRelatedKey("erip_path"); }

    public static function dueInterval() { return self::getCmsRelatedKey("due_interval"); }

    public static function cookiePath() { return self::getCmsRelatedKey("cookie_path"); }

    public static function paymentMethodNameWebpay() { return self::getCmsRelatedKey("payment_method_name_webpay"); }

    public static function paymentMethodDetailsWebpay() { return self::getCmsRelatedKey("payment_method_details_webpay"); }
}
