<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 16.02.2018
 * Time: 12:49
 */

namespace esas\cmsgate\hutkigrosh\protocol;


use esas\cmsgate\protocol\Amount;

class HutkigroshBillInfoRs extends HutkigroshRs
{
    private $billId;
    private $orderId;
    private $fullName;
    private $mobilePhone;
    private $email;
    private $fullAddress;
    private $retailOutletId;
    /**
     * @var Amount
     */
    private $amount;
    private $products;
    private $status;

    public function getBillId() { return $this->billId; }
    public function setBillId($billId) { $this->billId = trim($billId); }

    public function getOrderId() { return $this->orderId; }
    public function setOrderId($orderId) { $this->orderId = $orderId; return $this; }

    public function getInvId() { return $this->getOrderId(); }
    public function setInvId($invId) { $this->setOrderId($invId); }

    public function getFullName() { return $this->fullName; }
    public function setFullName($fullName) { $this->fullName = self::arraySafe($fullName); }

    public function getMobilePhone() { return $this->mobilePhone; }
    public function setMobilePhone($mobilePhone) { $this->mobilePhone = self::arraySafe($mobilePhone); }

    public function getEmail() { return $this->email; }
    public function setEmail($email) { $this->email = self::arraySafe($email); }

    public function getFullAddress() { return $this->fullAddress; }
    public function setFullAddress($fullAddress) { $this->fullAddress = self::arraySafe($fullAddress); }

    public function getRetailOutletId() { return $this->retailOutletId; }
    public function setRetailOutletId($retailOutletId) { $this->retailOutletId = $retailOutletId; }

    public function getAmount() { return $this->amount; }
    public function setAmount(Amount $amount) { $this->amount = $amount; }

    public function getProducts() { return $this->products; }
    public function setProducts($products) { $this->products = $products; }

    public function getStatus() { return $this->status; }
    public function setStatus($status) { $this->status = trim($status); }

    public function isStatusPayed()
    {
        return strtoupper($this->status) == 'PAYED';
    }

    public function isStatusCanceled()
    {
        return in_array($this->status, array('Outstending', 'DeletedByUser', 'PaymentCancelled', 'CANCELED'));
    }

    public function isStatusPending()
    {
        return in_array($this->status, array('PaymentPending', 'NotSet', 'PENDING', 'CREATED', 'ACTIVE'));
    }
}