<?php

class msPaymentHutkigroshSaveSettingsProcessor extends modProcessor
{
    public $languageTopics = ['minishop2:msp.hutkigrosh'];
    public $permission = 'settings';

    protected $settingKeys = [
        'hutkigrosh_shop_name'            => 'textfield',
        'hutkigrosh_api_token'            => 'text-password',
        'hutkigrosh_service_id'           => 'textfield',
        'hutkigrosh_retail_outlet_id'     => 'textfield',
        'hutkigrosh_cash_box_id'          => 'textfield',
        'hutkigrosh_metadata_cache'       => 'textarea',
        'hutkigrosh_sandbox'              => 'combo-boolean',
        'hutkigrosh_debug_mode'           => 'combo-boolean',
        'hutkigrosh_instructions_section' => 'combo-boolean',
        'hutkigrosh_qrcode_section'       => 'combo-boolean',
        'hutkigrosh_webpay_section'       => 'combo-boolean',
        'hutkigrosh_notification_email'   => 'combo-boolean',
        'hutkigrosh_notification_sms'     => 'combo-boolean',
        'hutkigrosh_bill_status_pending'  => 'numberfield',
        'hutkigrosh_bill_status_payed'    => 'numberfield',
        'hutkigrosh_bill_status_failed'   => 'numberfield',
        'hutkigrosh_bill_status_canceled' => 'numberfield',
        'hutkigrosh_due_interval'         => 'numberfield',
        'hutkigrosh_success_resource_id'  => 'numberfield',
        'hutkigrosh_failed_resource_id'   => 'numberfield',
        'hutkigrosh_erip_path'            => 'textfield',
    ];

    public function process()
    {
        $settings = $this->getProperty('settings');
        if (is_string($settings)) {
            $settings = json_decode($settings, true);
        }

        if (!is_array($settings)) {
            return $this->failure('Invalid settings data');
        }

        foreach ($this->settingKeys as $key => $xtype) {
            if (!array_key_exists($key, $settings)) {
                continue;
            }

            $value = $settings[$key];

            // Не сохранять пустой токен
            if ($key === 'hutkigrosh_api_token' && empty($value)) {
                continue;
            }

            $dbKey = 'ms2_msp' . $key;

            if ($xtype === 'combo-boolean') {
                $value = ($value === '1' || $value === 1 || $value === true) ? '1' : '0';
            }

            $setting = $this->modx->getObject('modSystemSetting', ['key' => $dbKey]);
            if (!$setting) {
                $setting = $this->modx->newObject('modSystemSetting');
                $setting->set('key', $dbKey);
                $setting->set('namespace', 'minishop2');
                $setting->set('area', 'msphutkigrosh');
                if ($xtype === 'combo-boolean') {
                    $setting->set('xtype', 'combo-boolean');
                } elseif ($xtype === 'text-password') {
                    $setting->set('xtype', 'text-password');
                } elseif ($xtype === 'numberfield') {
                    $setting->set('xtype', 'numberfield');
                } else {
                    $setting->set('xtype', 'textfield');
                }
            }
            $setting->set('value', $value);
            $setting->save();
        }

        $this->modx->cacheManager->refresh();

        return $this->success();
    }
}

return 'msPaymentHutkigroshSaveSettingsProcessor';
