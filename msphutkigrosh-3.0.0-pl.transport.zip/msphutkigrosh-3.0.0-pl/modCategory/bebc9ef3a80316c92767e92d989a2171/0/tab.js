/**
 * Вкладка «Настройки ХуткiГрош» в окне редактирования способа оплаты miniShop2.
 * Подключается через событие msOnManagerCustomCssJs в плагине hutkigrosh.
 */
(function () {

    var isHutkigrosh = function (config) {
        return config.record && config.record.class === 'Hutkigrosh';
    };

    var originalGetFields = miniShop2.window.UpdatePayment.prototype.getFields;
    var originalSubmit = miniShop2.window.UpdatePayment.superclass.submit;
    var originalShow = miniShop2.window.UpdatePayment.superclass.show;

    // Разбор JSON metadata из скрытого поля
    var loadMetadataFromField = function (config) {
        var field = Ext.getCmp(config.id + '-hutkigrosh-metadata-cache');
        if (field && field.getValue()) {
            try {
                return Ext.util.JSON.decode(field.getValue());
            } catch (e) {
                return null;
            }
        }
        return null;
    };

    // Сохранение metadata в скрытое поле
    var saveMetadataToField = function (config, data) {
        var field = Ext.getCmp(config.id + '-hutkigrosh-metadata-cache');
        if (field) {
            field.setValue(Ext.util.JSON.encode(data));
        }
    };

    // Заполнение combo «Код услуги»
    var fillServiceCombo = function (config, services, currentValue) {
        var combo = Ext.getCmp(config.id + '-hutkigrosh-service-id');
        if (!combo) return;
        var store = combo.getStore();
        store.removeAll();
        Ext.each(services, function (item) {
            store.add(new store.recordType({'code': String(item.code), 'name': item.name + ' (' + item.code + ')'}, String(item.code)));
        });
        combo.setValue(currentValue ? String(currentValue) : '');
        if (services.length === 1) {
            combo.setValue(String(services[0].code));
        }
    };

    // Заполнение combo «Код торговой точки»
    var fillOutletCombo = function (config, outlets, currentValue) {
        var combo = Ext.getCmp(config.id + '-hutkigrosh-retail-outlet-id');
        if (!combo) return;
        var store = combo.getStore();
        store.removeAll();
        Ext.each(outlets, function (item) {
            store.add(new store.recordType({'code': String(item.code), 'name': item.name + ' (' + item.code + ')'}, String(item.code)));
        });
        combo.setValue(currentValue ? String(currentValue) : '');
        if (outlets.length === 1) {
            combo.setValue(String(outlets[0].code));
        }
    };

    // Заполнение combo «Код кассы» по выбранной торговой точке
    var fillCashboxCombo = function (config, metadata, outletCode, currentValue) {
        var combo = Ext.getCmp(config.id + '-hutkigrosh-cash-box-id');
        if (!combo) return;
        var store = combo.getStore();
        store.removeAll();
        if (!metadata || !metadata.retailOutlets) return;
        Ext.each(metadata.retailOutlets, function (outlet) {
            if (String(outlet.code) === String(outletCode) && outlet.cashBoxes) {
                Ext.each(outlet.cashBoxes, function (box) {
                    store.add(new store.recordType({'code': String(box.code), 'name': box.name + ' (' + box.code + ')'}, String(box.code)));
                });
                if (outlet.cashBoxes.length === 1) {
                    combo.setValue(String(outlet.cashBoxes[0].code));
                } else {
                    combo.setValue(currentValue ? String(currentValue) : '');
                }
            }
        });
    };

    // Обновить все combo из metadata
    var refreshCombos = function (config, metadata) {
        var svc = Ext.getCmp(config.id + '-hutkigrosh-service-id');
        var out = Ext.getCmp(config.id + '-hutkigrosh-retail-outlet-id');
        var cb = Ext.getCmp(config.id + '-hutkigrosh-cash-box-id');
        var currentSvc = svc ? svc.getValue() : '';
        var currentOut = out ? out.getValue() : '';
        var currentCb = cb ? cb.getValue() : '';

        if (metadata.services) fillServiceCombo(config, metadata.services, currentSvc);
        if (metadata.retailOutlets) fillOutletCombo(config, metadata.retailOutlets, currentOut);

        // Перечитываем значение торговой точки после её автоматического выбора (при единственном элементе)
        var actualOut = out ? out.getValue() : '';
        if (!actualOut && metadata.retailOutlets && metadata.retailOutlets.length === 1) {
            actualOut = String(metadata.retailOutlets[0].code);
        }
        fillCashboxCombo(config, metadata, actualOut, currentCb);
    };

    // Возвращает поля настроек hutkigrosh для вкладки
    var getHutkigroshFields = function (config) {
        // Хранилища данных для combo (Ext.data.SimpleStore)
        var emptyStore = new Ext.data.SimpleStore({
            fields: ['code', 'name'],
            data: []
        });

        return [{
            xtype: 'textfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_shop_name'),
            name: 'hutkigrosh_shop_name',
            anchor: '99%',
            id: config.id + '-hutkigrosh-shop-name'
        }, {
            xtype: 'textfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_api_token'),
            name: 'hutkigrosh_api_token',
            inputType: 'password',
            anchor: '99%',
            id: config.id + '-hutkigrosh-api-token'
        }, {
            xtype: 'button',
            text: _('ms2_msphutkigrosh_btn_actualize'),
            cls: 'primary-button',
            style: 'margin-bottom: 10px',
            handler: function () {
                var tokenField = Ext.getCmp(config.id + '-hutkigrosh-api-token');
                var token = tokenField ? tokenField.getValue() : '';
                if (!token) {
                    MODx.msg.alert(_('error'), _('ms2_msphutkigrosh_err_no_token'));
                    return;
                }
                MODx.Ajax.request({
                    url: miniShop2.config['connector_url'],
                    params: {
                        action: 'mgr/settings/payment/hutkigrosh/metadata',
                        api_token: token
                    },
                    listeners: {
                        success: {
                            fn: function (response) {
                                if (response.object) {
                                    saveMetadataToField(config, response.object);
                                    refreshCombos(config, response.object);
                                }
                            },
                            scope: this
                        },
                        failure: {
                            fn: function (response) {
                                MODx.msg.alert(_('error'), response.message || _('ms2_msphutkigrosh_err_metadata'));
                            },
                            scope: this
                        }
                    }
                });
            },
            scope: this
        }, {
            xtype: 'combo',
            fieldLabel: _('setting_ms2_msphutkigrosh_service_id'),
            name: 'hutkigrosh_service_id',
            anchor: '99%',
            id: config.id + '-hutkigrosh-service-id',
            hiddenName: 'hutkigrosh_service_id',
            valueField: 'code',
            displayField: 'name',
            mode: 'local',
            store: emptyStore,
            triggerAction: 'all',
            editable: false,
            selectOnFocus: true,
            forceSelection: true
        }, {
            xtype: 'combo',
            fieldLabel: _('setting_ms2_msphutkigrosh_retail_outlet_id'),
            name: 'hutkigrosh_retail_outlet_id',
            anchor: '99%',
            id: config.id + '-hutkigrosh-retail-outlet-id',
            hiddenName: 'hutkigrosh_retail_outlet_id',
            valueField: 'code',
            displayField: 'name',
            mode: 'local',
            store: new Ext.data.SimpleStore({fields: ['code', 'name'], data: []}),
            triggerAction: 'all',
            editable: false,
            selectOnFocus: true,
            forceSelection: true,
            listeners: {
                select: function () {
                    var metadata = loadMetadataFromField(config);
                    if (metadata) {
                        var cbField = Ext.getCmp(config.id + '-hutkigrosh-cash-box-id');
                        var currentCb = cbField ? cbField.getValue() : '';
                        fillCashboxCombo(config, metadata, this.getValue(), currentCb);
                    }
                }
            }
        }, {
            xtype: 'combo',
            fieldLabel: _('setting_ms2_msphutkigrosh_cash_box_id'),
            name: 'hutkigrosh_cash_box_id',
            anchor: '99%',
            id: config.id + '-hutkigrosh-cash-box-id',
            hiddenName: 'hutkigrosh_cash_box_id',
            valueField: 'code',
            displayField: 'name',
            mode: 'local',
            store: new Ext.data.SimpleStore({fields: ['code', 'name'], data: []}),
            triggerAction: 'all',
            editable: false,
            selectOnFocus: true,
            forceSelection: true
        }, {
            // Скрытое поле для хранения metadata JSON
            xtype: 'hidden',
            name: 'hutkigrosh_metadata_cache',
            id: config.id + '-hutkigrosh-metadata-cache'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_sandbox'),
            hideLabel: true,
            name: 'hutkigrosh_sandbox',
            id: config.id + '-hutkigrosh-sandbox'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_debug_mode'),
            hideLabel: true,
            name: 'hutkigrosh_debug_mode',
            id: config.id + '-hutkigrosh-debug-mode'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_instructions_section'),
            hideLabel: true,
            name: 'hutkigrosh_instructions_section',
            id: config.id + '-hutkigrosh-instructions-section'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_qrcode_section'),
            hideLabel: true,
            name: 'hutkigrosh_qrcode_section',
            id: config.id + '-hutkigrosh-qrcode-section'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_webpay_section'),
            hideLabel: true,
            name: 'hutkigrosh_webpay_section',
            id: config.id + '-hutkigrosh-webpay-section'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_notification_email'),
            hideLabel: true,
            name: 'hutkigrosh_notification_email',
            id: config.id + '-hutkigrosh-notification-email'
        }, {
            xtype: 'xcheckbox',
            boxLabel: _('setting_ms2_msphutkigrosh_notification_sms'),
            hideLabel: true,
            name: 'hutkigrosh_notification_sms',
            id: config.id + '-hutkigrosh-notification-sms'
        }, {
            xtype: 'minishop2-combo-status',
            fieldLabel: _('setting_ms2_msphutkigrosh_bill_status_pending'),
            name: 'hutkigrosh_bill_status_pending',
            anchor: '99%',
            id: config.id + '-hutkigrosh-bill-status-pending'
        }, {
            xtype: 'minishop2-combo-status',
            fieldLabel: _('setting_ms2_msphutkigrosh_bill_status_payed'),
            name: 'hutkigrosh_bill_status_payed',
            anchor: '99%',
            id: config.id + '-hutkigrosh-bill-status-payed'
        }, {
            xtype: 'minishop2-combo-status',
            fieldLabel: _('setting_ms2_msphutkigrosh_bill_status_failed'),
            name: 'hutkigrosh_bill_status_failed',
            anchor: '99%',
            id: config.id + '-hutkigrosh-bill-status-failed'
        }, {
            xtype: 'minishop2-combo-status',
            fieldLabel: _('setting_ms2_msphutkigrosh_bill_status_canceled'),
            name: 'hutkigrosh_bill_status_canceled',
            anchor: '99%',
            id: config.id + '-hutkigrosh-bill-status-canceled'
        }, {
            xtype: 'numberfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_due_interval'),
            name: 'hutkigrosh_due_interval',
            anchor: '99%',
            id: config.id + '-hutkigrosh-due-interval',
            allowDecimals: false,
            minValue: 0
        }, {
            xtype: 'numberfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_success_resource_id'),
            name: 'hutkigrosh_success_resource_id',
            anchor: '99%',
            id: config.id + '-hutkigrosh-success-resource-id',
            allowDecimals: false
        }, {
            xtype: 'numberfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_failed_resource_id'),
            name: 'hutkigrosh_failed_resource_id',
            anchor: '99%',
            id: config.id + '-hutkigrosh-failed-resource-id',
            allowDecimals: false
        }, {
            xtype: 'textfield',
            fieldLabel: _('setting_ms2_msphutkigrosh_erip_path'),
            name: 'hutkigrosh_erip_path',
            anchor: '99%',
            id: config.id + '-hutkigrosh-erip-path'
        }];
    };

    // Переопределяем getFields — добавляем вкладку для Hutkigrosh
    miniShop2.window.UpdatePayment.override({
        getFields: function (config) {
            var fields = originalGetFields.call(this, config);

            if (isHutkigrosh(config)) {
                fields[0].items.push({
                    title: _('ms2_msphutkigrosh_tab_settings'),
                    layout: 'form',
                    defaults: {msgTarget: 'under'},
                    items: getHutkigroshFields(config),
                    listeners: {
                        afterrender: function (p) {
                            p.body.dom.style.overflowY = 'auto';
                            p.body.dom.style.maxHeight = '400px';
                        }
                    }
                });
            }

            return fields;
        }
    });

    // Переопределяем show — загружаем настройки после отображения окна
    miniShop2.window.UpdatePayment.override({
        show: function () {
            originalShow.apply(this, arguments);

            if (isHutkigrosh(this.config) && !this._hutkigroshLoaded) {
                this._hutkigroshLoaded = true;
                var me = this;

                MODx.Ajax.request({
                    url: miniShop2.config['connector_url'],
                    params: {
                        action: 'mgr/settings/payment/hutkigrosh/getsettings'
                    },
                    listeners: {
                        success: {
                            fn: function (response) {
                                if (response.object) {
                                    me.fp.getForm().setValues(response.object);
                                    // Восстанавливаем combo из кешированного metadata
                                    var metadata = null;
                                    if (response.object.hutkigrosh_metadata_cache) {
                                        try {
                                            metadata = Ext.util.JSON.decode(response.object.hutkigrosh_metadata_cache);
                                        } catch (e) {}
                                    }
                                    if (metadata) {
                                        refreshCombos(me.config, metadata);
                                    }
                                }
                            },
                            scope: this
                        }
                    }
                });
            }
        }
    });

    // Переопределяем submit — сначала сохраняем настройки, потом платёж
    miniShop2.window.UpdatePayment.override({
        submit: function (close) {
            var f = this.fp.getForm();
            if (!f.isValid()) {
                return false;
            }

            var allValues = f.getValues();
            var hutkigroshSettings = {};
            var hasHutkigroshFields = false;

            Ext.iterate(allValues, function (key, value) {
                if (key.indexOf('hutkigrosh_') === 0) {
                    hutkigroshSettings[key] = value;
                    hasHutkigroshFields = true;
                }
            });

            var me = this;

            if (!hasHutkigroshFields) {
                originalSubmit.call(me, close);
                return;
            }

            MODx.Ajax.request({
                url: miniShop2.config['connector_url'],
                params: {
                    action: 'mgr/settings/payment/hutkigrosh/savesettings',
                    settings: Ext.util.JSON.encode(hutkigroshSettings)
                },
                listeners: {
                    success: {
                        fn: function () {
                            originalSubmit.call(me, close);
                        },
                        scope: me
                    },
                    failure: {
                        fn: function (response) {
                            MODx.msg.alert(_('error'), response.message);
                        },
                        scope: me
                    }
                }
            });
        }
    });

})();
