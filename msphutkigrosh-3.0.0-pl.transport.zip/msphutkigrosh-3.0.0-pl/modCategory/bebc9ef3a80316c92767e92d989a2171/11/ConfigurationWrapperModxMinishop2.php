<?php
namespace esas\cmsgate\hutkigrosh\wrappers;

use esas\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use esas\cmsgate\hutkigrosh\ConfigStorageModxMinishop2;
use esas\cmsgate\hutkigrosh\ConfigurationFieldsModx;
use esas\cmsgate\utils\Logger;

class ConfigurationWrapperModxMinishop2 extends ConfigWrapperHutkigrosh
{
    public $modx;

    /** Переопределения настроек (используются процессором metadata для передачи api_token из формы) */
    protected $overrides = [];

    /**
     * @param $modx
     * @param array $overrides
     */
    public function __construct(&$modx, $overrides = [])
    {
        $configStorage = new ConfigStorageModxMinishop2($modx);
        parent::__construct($configStorage);
        $this->modx = $modx;
        $this->overrides = $overrides;
    }

    public function getShopName()
    {
        return $this->getOption(ConfigurationFieldsModx::SHOP_NAME, true);
    }

    /**
     * Токен API для доступа к системе ХуткиГрош
     * @return string
     */
    public function getHutkigroshApiToken()
    {
        if (isset($this->overrides[ConfigurationFieldsModx::API_TOKEN]))
            return $this->overrides[ConfigurationFieldsModx::API_TOKEN];
        return $this->getOption(ConfigurationFieldsModx::API_TOKEN, true);
    }

    /**
     * Включен ли режим песочницы
     * @return boolean
     */
    public function isSandbox()
    {
        return $this->checkOn(ConfigurationFieldsModx::SANDBOX);
    }

    /**
     * Код торговой точки
     * @return string
     */
    public function getRetailOutletId()
    {
        if (isset($this->overrides[ConfigurationFieldsModx::RETAIL_OUTLET_ID]))
            return $this->overrides[ConfigurationFieldsModx::RETAIL_OUTLET_ID];
        return $this->getOption(ConfigurationFieldsModx::RETAIL_OUTLET_ID, true);
    }

    /**
     * Код услуги
     * @return string
     */
    public function getServiceId()
    {
        if (isset($this->overrides[ConfigurationFieldsModx::SERVICE_ID]))
            return $this->overrides[ConfigurationFieldsModx::SERVICE_ID];
        return $this->getOption(ConfigurationFieldsModx::SERVICE_ID, true);
    }

    /**
     * Код кассы
     * @return string
     */
    public function getCashboxId()
    {
        if (isset($this->overrides[ConfigurationFieldsModx::CASH_BOX_ID]))
            return $this->overrides[ConfigurationFieldsModx::CASH_BOX_ID];
        return $this->getOption(ConfigurationFieldsModx::CASH_BOX_ID, true);
    }

    public function isEmailNotification()
    {
        return $this->checkOn(ConfigurationFieldsModx::EMAIL_NOTIFICATION);
    }

    public function isSmsNotification()
    {
        return $this->checkOn(ConfigurationFieldsModx::SMS_NOTIFICATION);
    }

    public function getCompletionText()
    {
        // TODO: Implement getCompletionText() method.
    }

    public function getBillStatusPending()
    {
        return $this->getOption(ConfigurationFieldsModx::BILL_STATUS_PENDING, true);
    }

    public function getBillStatusPayed()
    {
        return $this->getOption(ConfigurationFieldsModx::BILL_STATUS_PAYED, true);
    }

    public function getBillStatusFailed()
    {
        return $this->getOption(ConfigurationFieldsModx::BILL_STATUS_FAILED, true);
    }

    public function getBillStatusCanceled()
    {
        return $this->getOption(ConfigurationFieldsModx::BILL_STATUS_CANCELED, true);
    }

    public function getSuccessResourceId()
    {
        return $this->getOption(ConfigurationFieldsModx::SUCCESS_RESOURCE_ID, true);
    }

    public function getFailedResourceId()
    {
        return $this->getOption(ConfigurationFieldsModx::FAILED_RESOURCE_ID, true);
    }

    /**
     * Включен ли раздел инструкции
     * @return boolean
     */
    public function isInstructionsSectionEnabled()
    {
        return $this->checkOn(ConfigurationFieldsModx::INSTRUCTIONS_SECTION);
    }

    /**
     * Включен ли раздел QR-кода
     * @return boolean
     */
    public function isQRCodeSectionEnabled()
    {
        return $this->checkOn(ConfigurationFieldsModx::QRCODE_SECTION);
    }

    /**
     * Включен ли раздел Webpay
     * @return boolean
     */
    public function isWebpaySectionEnabled()
    {
        return $this->checkOn(ConfigurationFieldsModx::WEBPAY_SECTION);
    }

    /**
     * Включен ли режим отладки
     * @return boolean
     */
    public function isDebugMode()
    {
        return $this->checkOn(ConfigurationFieldsModx::DEBUG_MODE);
    }

    public function getPaymentMethodName()
    {
        // TODO: не используется
    }

    public function getPaymentMethodDetails()
    {
        // TODO: не используется
    }

    public function getEripPath()
    {
        return $this->getOption(ConfigurationFieldsModx::ERIP_PATH, true);
    }

    public function getDueInterval()
    {
        return $this->getOption(ConfigurationFieldsModx::DUE_INTERVAL, true);
    }

    public function createCmsRelatedKey($key) {
        return $key;
    }

    public function isUseOrderNumber(){
        return true;
    }

    protected function checkOn($key, $warn = false)
    {
        $value = $this->modx->getOption('ms2_msp' . $key, null, '0');
        return $value == '1' || $value == "true";
    }

    public function getOption($key, $warn = false)
    {
        Logger::getLogger(get_class($this))->info("getOption " . 'ms2_msp' . $key);
        $value = $this->modx->getOption('ms2_msp' . $key, null, '');
        if ($warn)
            return $this->warnIfEmpty($value, $key);
        else
            return $value;
    }
}
