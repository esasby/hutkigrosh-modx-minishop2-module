<?php

class msPaymentHutkigroshGetSettingsProcessor extends modProcessor
{
    public $languageTopics = ['minishop2:msp.hutkigrosh'];
    public $permission = 'settings';

    protected $settingKeys = [
        'hutkigrosh_shop_name',
        'hutkigrosh_api_token',
        'hutkigrosh_service_id',
        'hutkigrosh_retail_outlet_id',
        'hutkigrosh_cash_box_id',
        'hutkigrosh_metadata_cache',
        'hutkigrosh_sandbox',
        'hutkigrosh_debug_mode',
        'hutkigrosh_instructions_section',
        'hutkigrosh_qrcode_section',
        'hutkigrosh_webpay_section',
        'hutkigrosh_notification_email',
        'hutkigrosh_notification_sms',
        'hutkigrosh_bill_status_pending',
        'hutkigrosh_bill_status_payed',
        'hutkigrosh_bill_status_failed',
        'hutkigrosh_bill_status_canceled',
        'hutkigrosh_due_interval',
        'hutkigrosh_success_resource_id',
        'hutkigrosh_failed_resource_id',
        'hutkigrosh_erip_path',
    ];

    protected $booleanKeys = [
        'hutkigrosh_sandbox',
        'hutkigrosh_debug_mode',
        'hutkigrosh_instructions_section',
        'hutkigrosh_qrcode_section',
        'hutkigrosh_webpay_section',
        'hutkigrosh_notification_email',
        'hutkigrosh_notification_sms',
    ];

    public function process()
    {
        $result = [];
        foreach ($this->settingKeys as $key) {
            $value = $this->modx->getOption('ms2_msp' . $key, null, '');
            if (in_array($key, $this->booleanKeys)) {
                $result[$key] = ($value === '1' || $value === 'true');
            } else {
                $result[$key] = $value;
            }
        }
        return $this->success('', $result);
    }
}

return 'msPaymentHutkigroshGetSettingsProcessor';
