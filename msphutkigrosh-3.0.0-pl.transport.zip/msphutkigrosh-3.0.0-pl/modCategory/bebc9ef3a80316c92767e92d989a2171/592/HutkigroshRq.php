<?php

namespace esas\cmsgate\hutkigrosh\protocol;

use esas\cmsgate\utils\Logger;

class HutkigroshRq
{
    protected $logger;

    private $retailOutlets;
    private $services;
    private $cashboxes;

    private $retailOutletId;
    private $serviceId;
    private $cashboxId;
    private $paymentChannels;

    public function __construct()
    {
        $this->logger = Logger::getLogger(get_class($this));
    }

    public function getRetailOutletId() { return $this->retailOutletId; }
    public function setRetailOutletId($retailOutletId) { $this->retailOutletId = trim($retailOutletId); }

    public function getServiceId() { return $this->serviceId; }
    public function setServiceId($serviceId) { $this->serviceId = trim($serviceId); }

    public function getCashboxId() { return $this->cashboxId; }
    public function setCashboxId($cashboxId) { $this->cashboxId = trim($cashboxId); }

    public function getPaymentChannels() { return $this->paymentChannels; }
    public function setPaymentChannels($paymentChannels) { $this->paymentChannels = $paymentChannels; }

    public function getRetailOutlets() { return $this->retailOutlets; }
    public function setRetailOutlets($retailOutlets) { $this->retailOutlets = $retailOutlets; }

    public function getServices() { return $this->services; }
    public function setServices($services) { $this->services = $services; }

    public function getCashboxes() { return $this->cashboxes; }
    public function setCashboxes($cashboxes) { $this->cashboxes = $cashboxes; }
}
