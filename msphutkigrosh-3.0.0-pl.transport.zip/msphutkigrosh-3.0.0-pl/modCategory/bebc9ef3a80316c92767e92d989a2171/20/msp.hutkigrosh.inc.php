<?php

$_lang['area_msphutkigrosh'] = "ХуткiГрош";

$_lang['setting_ms2_msphutkigrosh_shop_name'] = 'Название магазина';
$_lang['setting_ms2_msphutkigrosh_shop_name_desc'] = 'Произвольное название Вашего магазина';

$_lang['setting_ms2_msphutkigrosh_api_token'] = 'API Token';
$_lang['setting_ms2_msphutkigrosh_api_token_desc'] = 'Токен для доступа к API ХуткiГрош (получается в личном кабинете)';

$_lang['setting_ms2_msphutkigrosh_service_id'] = 'Код услуги';
$_lang['setting_ms2_msphutkigrosh_service_id_desc'] = 'Код услуги из списка "Услуги" (заполняется после нажатия кнопки "Актуализировать")';

$_lang['setting_ms2_msphutkigrosh_retail_outlet_id'] = 'Код торговой точки';
$_lang['setting_ms2_msphutkigrosh_retail_outlet_id_desc'] = 'Код торговой точки из списка "Розничные торговые точки" (заполняется после нажатия кнопки "Актуализировать")';

$_lang['setting_ms2_msphutkigrosh_cash_box_id'] = 'Код кассы';
$_lang['setting_ms2_msphutkigrosh_cash_box_id_desc'] = 'Код кассы из списка "Кассы" (заполняется после нажатия кнопки "Актуализировать")';

$_lang['setting_ms2_msphutkigrosh_sandbox'] = 'Песочница';
$_lang['setting_ms2_msphutkigrosh_sandbox_desc'] = 'Режим "песочницы". Если включен, то все запросы будут отправляться на тестовый сервер';

$_lang['setting_ms2_msphutkigrosh_debug_mode'] = 'Режим отладки';
$_lang['setting_ms2_msphutkigrosh_debug_mode_desc'] = 'Если включен, в лог записывается дополнительная отладочная информация';

$_lang['setting_ms2_msphutkigrosh_instructions_section'] = 'Инструкция по оплате';
$_lang['setting_ms2_msphutkigrosh_instructions_section_desc'] = 'Если включено, то на итоговом экране клиенту отобразится инструкция по оплате в ЕРИП';

$_lang['setting_ms2_msphutkigrosh_qrcode_section'] = 'QR-код';
$_lang['setting_ms2_msphutkigrosh_qrcode_section_desc'] = 'Если включено, то на итоговом экране клиенту отобразится QR-код для оплаты';

$_lang['setting_ms2_msphutkigrosh_webpay_section'] = 'Оплата картой (Webpay)';
$_lang['setting_ms2_msphutkigrosh_webpay_section_desc'] = 'Если включено, то на итоговом экране клиенту отобразится кнопка для оплаты счёта картой';

$_lang['setting_ms2_msphutkigrosh_notification_email'] = 'Email оповещение';
$_lang['setting_ms2_msphutkigrosh_notification_email_desc'] = 'Если включено, шлюз ХуткiГрош будет отправлять email оповещение клиенту о выставлении счёта';

$_lang['setting_ms2_msphutkigrosh_notification_sms'] = 'SMS оповещение';
$_lang['setting_ms2_msphutkigrosh_notification_sms_desc'] = 'Если включено, шлюз ХуткiГрош будет отправлять SMS оповещение клиенту о выставлении счёта';

$_lang['setting_ms2_msphutkigrosh_bill_status_pending'] = 'Статус при выставлении счёта';
$_lang['setting_ms2_msphutkigrosh_bill_status_pending_desc'] = 'Какой статус выставить заказу при успешном выставлении счёта (идентификатор статуса)';

$_lang['setting_ms2_msphutkigrosh_bill_status_payed'] = 'Статус при оплате счёта';
$_lang['setting_ms2_msphutkigrosh_bill_status_payed_desc'] = 'Какой статус выставить заказу при успешной оплате счёта (идентификатор статуса)';

$_lang['setting_ms2_msphutkigrosh_bill_status_failed'] = 'Статус при ошибке';
$_lang['setting_ms2_msphutkigrosh_bill_status_failed_desc'] = 'Какой статус выставить заказу при ошибке выставления счёта (идентификатор статуса)';

$_lang['setting_ms2_msphutkigrosh_bill_status_canceled'] = 'Статус при отмене';
$_lang['setting_ms2_msphutkigrosh_bill_status_canceled_desc'] = 'Какой статус выставить заказу при отмене оплаты счёта (идентификатор статуса)';

$_lang['setting_ms2_msphutkigrosh_success_resource_id'] = 'Ресурс при успехе';
$_lang['setting_ms2_msphutkigrosh_success_resource_id_desc'] = 'Идентификатор ресурса для перехода при успешном выставлении счёта';

$_lang['setting_ms2_msphutkigrosh_failed_resource_id'] = 'Ресурс при ошибке';
$_lang['setting_ms2_msphutkigrosh_failed_resource_id_desc'] = 'Идентификатор ресурса для перехода при ошибке выставления счёта';

$_lang['setting_ms2_msphutkigrosh_due_interval'] = 'Срок действия счёта (дней)';
$_lang['setting_ms2_msphutkigrosh_due_interval_desc'] = 'Сколько дней счёт будет доступен в ЕРИП для оплаты';

$_lang['setting_ms2_msphutkigrosh_erip_path'] = 'Путь в дереве ЕРИП';
$_lang['setting_ms2_msphutkigrosh_erip_path_desc'] = 'По какому пути клиент должен искать выставленный счёт';

$_lang['hutkigrosh.webpay.tab.label'] = 'Оплатить картой';
$_lang['hutkigrosh.webpay.details'] = 'Вы можете оплатить счёт с помощью карты Visa, Mastercard или Белкарт через систему электронных платежей WebPay';
$_lang['hutkigrosh.webpay.msg.success'] = 'Счёт успешно оплачен через WebPay';
$_lang['hutkigrosh.webpay.msg.failed'] = 'Ошибка оплаты счёта через WebPay';
$_lang['hutkigrosh.qrcode.tab.label'] = 'Оплата по QR-коду';
$_lang['hutkigrosh.qrcode.details'] = 'Оплатите счёт через мобильное банковское приложение по QR-коду';
$_lang['hutkigrosh.qrcode.label'] = 'Оплатить через QR-code';

$_lang['ms2_msphutkigrosh_tab_settings'] = 'Настройки ХуткiГрош';
$_lang['ms2_msphutkigrosh_btn_actualize'] = 'Актуализировать';
$_lang['ms2_msphutkigrosh_err_no_token'] = 'Заполните поле API Token перед актуализацией';
$_lang['ms2_msphutkigrosh_err_metadata'] = 'Ошибка получения данных от сервера ХуткiГрош';
