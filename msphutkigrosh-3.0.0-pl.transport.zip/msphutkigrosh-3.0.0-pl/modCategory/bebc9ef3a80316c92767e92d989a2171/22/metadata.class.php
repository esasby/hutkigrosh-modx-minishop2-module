<?php

use esas\cmsgate\CmsPlugin;
use esas\cmsgate\hutkigrosh\ConfigurationFieldsModx;
use esas\cmsgate\hutkigrosh\RegistryHutkigroshMs;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use esas\cmsgate\hutkigrosh\protocol\HutkigroshRq;
use esas\cmsgate\hutkigrosh\wrappers\ConfigurationWrapperModxMinishop2;

class msPaymentHutkigroshMetadataProcessor extends modProcessor
{
    public $languageTopics = ['minishop2:msp.hutkigrosh'];
    public $permission = 'settings';

    public function process()
    {
        $apiToken = $this->getProperty('api_token', '');
        if (empty($apiToken)) {
            return $this->failure($this->modx->lexicon('ms2_msphutkigrosh_err_no_token'));
        }

        try {
            // Инициализация Registry (гарантированная, т.к. MODX процессоры запускаются в отдельном контексте)
            $vendorDir = dirname(__FILE__, 7) . '/vendor';
            $cmsPluginDir = dirname(__FILE__, 6);
            if (!is_dir($vendorDir)) {
                $vendorDir = MODX_CORE_PATH . 'vendor';
            }
            $registry = new RegistryHutkigroshMs($this->modx);
            (new CmsPlugin($vendorDir, $cmsPluginDir))
                ->setRegistry($registry)
                ->init();

            $overrides = [
                ConfigurationFieldsModx::API_TOKEN => $apiToken,
            ];
            $configWrapper = new ConfigurationWrapperModxMinishop2($this->modx, $overrides);

            $hg = new HutkigroshProtocol($configWrapper);

            $rq = new HutkigroshRq();
            $hg->checkProviderMetadata($rq);

            $result = [
                'services' => [],
                'retailOutlets' => [],
            ];

            foreach ($rq->getServices() as $service) {
                $result['services'][] = [
                    'code' => $service['code'],
                    'name' => isset($service['name']) ? $service['name'] : $service['code'],
                ];
            }

            foreach ($rq->getRetailOutlets() as $outlet) {
                $outletData = [
                    'code' => $outlet['code'],
                    'name' => isset($outlet['name']) ? $outlet['name'] : $outlet['code'],
                    'cashBoxes' => [],
                ];
                if (isset($outlet['cashBoxes']) && is_array($outlet['cashBoxes'])) {
                    foreach ($outlet['cashBoxes'] as $box) {
                        $outletData['cashBoxes'][] = [
                            'code' => $box['code'],
                            'name' => isset($box['name']) ? $box['name'] : $box['code'],
                        ];
                    }
                }
                $result['retailOutlets'][] = $outletData;
            }

            return $this->success('', $result);
        } catch (\Exception $e) {
            return $this->failure($e->getMessage());
        }
    }
}

return 'msPaymentHutkigroshMetadataProcessor';
