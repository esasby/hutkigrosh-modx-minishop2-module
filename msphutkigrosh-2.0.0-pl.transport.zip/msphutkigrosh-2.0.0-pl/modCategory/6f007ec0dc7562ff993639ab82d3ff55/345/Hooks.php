<?php


namespace esas\cmsgate;


class Hooks
{

}