<?php


namespace esas\cmsgate\utils\htmlbuilder\page;


interface AbstractPage
{
    public function render();
}