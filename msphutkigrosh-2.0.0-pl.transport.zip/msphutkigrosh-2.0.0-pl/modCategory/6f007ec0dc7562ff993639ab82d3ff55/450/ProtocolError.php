<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 08.04.2020
 * Time: 13:28
 */

namespace esas\cmsgate\protocol;


class ProtocolError
{
    const ERROR_CONMECTION = 300;
    const ERROR_WRONG_MSG_FORMAT = 310;
}