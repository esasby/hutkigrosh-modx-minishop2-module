<?php


namespace esas\cmsgate\utils\htmlbuilder\page;


interface DisplayErrorPage extends AbstractPage
{
    public function isErrorPage();
}