<?php


namespace esas\cmsgate\dao;


use esas\cmsgate\service\Service;

abstract class Repository extends Service
{

}