function onSubmit(token) {
    document.getElementsByClassName("google-recaptcha-form")[0].submit();
}