<?php


namespace esas\cmsgate\hro\panels;

use esas\cmsgate\hro\HRO;

interface MessagesPanelHRO extends HRO
{

}