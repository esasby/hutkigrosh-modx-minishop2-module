<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 14.04.2020
 * Time: 14:59
 */

namespace esas\cmsgate\view;


class ViewFields
{
    const BUTTON_SAVE = 'button_save';
    const BUTTON_CONTINUE = 'button_continue';
    const BUTTON_CONFIRM = 'button_confirm';
    const CONTACTS = 'contacts';
}