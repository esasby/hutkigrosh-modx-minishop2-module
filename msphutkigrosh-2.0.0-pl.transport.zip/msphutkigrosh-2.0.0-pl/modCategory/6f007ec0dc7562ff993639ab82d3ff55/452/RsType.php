<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 21.01.2019
 * Time: 17:15
 */

namespace esas\cmsgate\protocol;


class RsType
{
    const _STRING = 0;
    const _ARRAY = 1;
    const _JSON = 1;
    const _XML = 2;
}