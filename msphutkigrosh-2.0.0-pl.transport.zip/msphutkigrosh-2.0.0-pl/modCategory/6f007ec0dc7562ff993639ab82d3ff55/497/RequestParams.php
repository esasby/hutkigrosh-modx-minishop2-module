<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 26.02.2019
 * Time: 12:49
 */

namespace esas\cmsgate\utils;


class RequestParams
{
    const ORDER_ID = "order_id";
    const ORDER_NUMBER = "order_number";
}