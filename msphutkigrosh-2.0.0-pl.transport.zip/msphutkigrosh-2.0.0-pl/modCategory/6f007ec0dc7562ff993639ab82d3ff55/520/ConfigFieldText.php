<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 01.10.2018
 * Time: 10:29
 */

namespace esas\cmsgate\view\admin\fields;


class ConfigFieldText extends ConfigField
{

}