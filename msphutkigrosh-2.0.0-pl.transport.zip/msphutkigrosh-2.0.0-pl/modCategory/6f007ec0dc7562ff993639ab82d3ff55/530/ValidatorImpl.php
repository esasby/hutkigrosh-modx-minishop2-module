<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 11.10.2018
 * Time: 13:29
 */

namespace esas\cmsgate\view\admin\validators;


class ValidatorImpl extends Validator
{

    /**
     * @return boolean
     */
    public function validateValue($value)
    {
        return true;
    }
}