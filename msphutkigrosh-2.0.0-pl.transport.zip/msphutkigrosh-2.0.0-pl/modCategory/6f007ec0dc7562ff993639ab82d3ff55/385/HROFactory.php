<?php


namespace esas\cmsgate\hro;


interface HROFactory
{
    public static function findBuilder();
}