<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 17.08.2018
 * Time: 10:59
 */

namespace esas\cmsgate\lang;


class Locale
{
    const ru_RU = 'ru_RU';
    const en_EN = 'en_EN';
}