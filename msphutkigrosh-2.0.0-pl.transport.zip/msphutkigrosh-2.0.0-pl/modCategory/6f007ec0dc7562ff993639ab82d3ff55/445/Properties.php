<?php


namespace esas\cmsgate\properties;


interface Properties
{

}