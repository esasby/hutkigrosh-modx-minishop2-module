<?php


namespace esas\cmsgate\properties;


interface SandboxProperties
{
    public function isSandbox();
}