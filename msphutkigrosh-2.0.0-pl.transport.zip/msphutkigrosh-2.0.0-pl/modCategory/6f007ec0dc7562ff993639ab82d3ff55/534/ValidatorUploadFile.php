<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 07.12.2018
 * Time: 11:55
 */

namespace esas\cmsgate\view\admin\validators;


abstract class ValidatorUploadFile extends Validator
{
}