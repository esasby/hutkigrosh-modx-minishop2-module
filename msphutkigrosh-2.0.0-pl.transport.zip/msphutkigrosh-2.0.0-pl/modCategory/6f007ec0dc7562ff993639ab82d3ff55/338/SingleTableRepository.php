<?php


namespace esas\cmsgate\dao;


interface SingleTableRepository
{
    public function getTableName();
}