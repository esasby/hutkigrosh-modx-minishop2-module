<?php


namespace esas\cmsgate\service;


interface ServiceProvider
{
    public function getServiceArray();
}