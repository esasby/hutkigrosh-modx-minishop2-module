<?php


namespace esas\cmsgate\properties;


interface LocaleProperties
{
    public function getLocale();
}